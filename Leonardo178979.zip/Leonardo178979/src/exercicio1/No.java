package exercicio1;

public class No {
	int numero;
	String cor;
	No prox;
	
	public No(int numero, String cor) {
		this.numero = numero;
		this.cor = cor;
	}
}

package exercicio4;

public class No {
	int dado;
	No esq;
	No dir;
	
	public No(int dado) {
		this.dado = dado;
	}
}

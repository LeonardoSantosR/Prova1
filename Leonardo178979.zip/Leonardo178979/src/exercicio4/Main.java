package exercicio4;

public class Main {
	public static void main(String[] args) {
		
		Lista lista = new Lista();
		
		// inser��o dos elementos na lista
		lista.inserir(10);
		lista.inserir(25);
		lista.inserir(15);
		lista.inserir(-3);
		lista.inserir(0);
		
		// impress�o dos elementos da lista
		lista.imprimir();

	}
}

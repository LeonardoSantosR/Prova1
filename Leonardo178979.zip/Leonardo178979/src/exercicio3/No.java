package exercicio3;

public class No {

	int dado;
	No dir;
	No esq;
	
	public No(int dado) {
		this.dado = dado;
	}
}
